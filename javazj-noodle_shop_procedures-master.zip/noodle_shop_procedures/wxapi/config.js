const CONFIG = require('../config.js')
module.exports = {
  version: "0.0.1",
  note: '构建框架',
  subDomain: CONFIG.subDomain
}