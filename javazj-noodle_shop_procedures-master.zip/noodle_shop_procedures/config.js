module.exports = {
  version: "0.0.1",
  note: '构建项目',
  subDomain: "noodles"
}