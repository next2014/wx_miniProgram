ActiveModelSerializers.config.adapter = :json_api
