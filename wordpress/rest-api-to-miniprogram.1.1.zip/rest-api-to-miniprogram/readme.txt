﻿=== REST API TO MiniProgram ===
Contributors: jianbo
Donate link: https://www.watch-life.net
Tags: 微信小程序,rest,api
Requires at least: 4.9.8
Tested up to: 4.7
Stable tag:1.0
Requires PHP: 5.6
License: GPL v3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

为微信小程序、app提供定制WordPress rest api 输出.支持微信支付、微信小程序模板消息.

详细介绍： <a href="https://www.watch-life.net">https://www.watch-life.net</a>

最新插件源代码更新地址：
<a href="https://github.com/iamxjb/rest-api-to-miniprogram">https://github.com/iamxjb/rest-api-to-miniprogram</a>



== Installation ==

1. 上传 `rest-api-to-miniprogram`目录 到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件

== Frequently Asked Questions ==

详细介绍： <a href="https://www.watch-life.net">https://www.watch-life.net</a>


== Screenshots ==

1.设置
2.专业版
3.微信小程序

== Changelog ==

= 1.1 =
修复新用户无法授权登录的问题。

= 1.0 =
修复wordpres升级5.0后插件与古藤堡编辑器无法兼容的问题。

= 0.8 =
* 初始版本

== Upgrade Notice == 

如果你曾经安装过wp-rest-api-for-app 请先卸载此插件,REST API TO MiniProgram无法与该插件同时使用,但会保持并加绒该插件的功能.
