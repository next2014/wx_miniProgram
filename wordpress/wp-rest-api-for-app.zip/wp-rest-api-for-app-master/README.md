# 新版本 WordpPress rest api  插件已发布，此版本将不在更新，新版本请访问：https://github.com/iamxjb/rest-api-to-miniprogram





# WordpPress rest api 定制化插件

# 为微信小程序、app提供定制WordPress rest api

# 技术支持网站：https://www.watch-life.net

# 技术支持微信：iamxjb

# 讨论微信群：

由于微信群超过100人，无法再扫描二维码加入。如果你想加入，请先加我的微信：iamxjb ，我拉你入群。

# 开源协议：GPL v3

# 插件使用及注意事项见：

https://www.watch-life.net/wordpress-weixin-app

# 镜像下载地址

如果因为某些原因github无法访问，请通过如下镜像地址下载：

https://gitee.com/iamxjb/wp-rest-api-for-app


# 使用说明：

插件安装启用后，需要设置文章分类目录：微信小程序封面，设置方法是进入wordpress管理后台，进入菜单：文章->分类目录，在微信小程序封面输入图片的链接地址即可，如下图所示：

![wp-rest-api-for-app1](https://www.watch-life.net/images/2017/07/cover.png) 

wordpress后台管理的设置菜单里面，找到“微信小程序设置”菜单，点击进入后，如下图所示：

![wp-rest-api-for-app2](https://www.watch-life.net/images/2017/09/option-openid-new.png) 






